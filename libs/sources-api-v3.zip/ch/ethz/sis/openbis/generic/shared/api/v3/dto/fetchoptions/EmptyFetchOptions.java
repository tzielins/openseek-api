package ch.ethz.sis.openbis.generic.shared.api.v3.dto.fetchoptions;

import ch.systemsx.cisd.base.annotation.JsonObject;

@JsonObject("dto.fetchoptions.EmptyFetchOptions")
public class EmptyFetchOptions extends FetchOptions
{

    private static final long serialVersionUID = 1L;

}
